import whisper
import cv2
from face_utils import recognize_faces

model = whisper.load_model("base")

def process_video(video_path):
    faces = recognize_faces(video_path)
    audio_result = model.transcribe(video_path)
    return f"Faces: {faces}, Transcript: {audio_result['text']}"
