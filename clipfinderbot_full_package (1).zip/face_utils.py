import face_recognition
import cv2

def recognize_faces(video_path):
    video = cv2.VideoCapture(video_path)
    frame_count = 0
    face_names = set()
    while frame_count < 30:
        ret, frame = video.read()
        if not ret:
            break
        rgb_frame = frame[:, :, ::-1]
        locations = face_recognition.face_locations(rgb_frame)
        encodings = face_recognition.face_encodings(rgb_frame, locations)
        face_names.update([f"face_{i}" for i in range(len(encodings))])
        frame_count += 1
    video.release()
    return list(face_names)
