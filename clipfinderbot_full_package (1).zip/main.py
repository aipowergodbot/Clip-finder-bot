import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from inference import process_video

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Welcome to ClipFinderBot! Send me a short video clip.")

async def handle_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    video = await update.message.video.get_file()
    video_path = "temp_video.mp4"
    await video.download_to_drive(video_path)
    result = process_video(video_path)
    await update.message.reply_text(f"Prediction: {result}")

if __name__ == "__main__":
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.VIDEO, handle_video))
    app.run_polling()
