# ClipFinderBot
A Telegram bot to identify movies/shows from short video clips using face recognition, Whisper for audio transcription, and CLIP models.
